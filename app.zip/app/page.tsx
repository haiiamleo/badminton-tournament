"use client";

import { useEffect, useMemo, useState } from "react";
import { supabase } from "../lib/supabase";
import {
  generateIntelligentPairings,
  generateRandomPairings,
  type Pairing,
} from "../lib/tournamentEngine";

type Player = {
  id: string;
  name: string;
  seed?: number | null;
  active?: boolean;
};

type MatchPlayer = {
  id?: string;
  match_id?: string;
  player_id: string;
  team_number: number;
};

type Match = {
  id: string;
  round_id: string;
  court_number: number | null;
  match_number: number;
  team1_score: number | null;
  team2_score: number | null;
  winner_team: number | null;
  status: string;
};

type Tournament = {
  id: string;
  name: string;
  total_players: number;
  preliminary_rounds: number;
  courts: number;
  qualification_count: number;
  status: string;
};

type Round = {
  id: string;
  tournament_id: string;
  round_number: number;
  round_type: string;
  status: string;
};

type Standing = {
  player_id: string;
  matches_played: number;
  wins: number;
  losses: number;
  points_for: number;
  points_against: number;
  tournament_points: number;
};

type ScoreState = {
  team1: string;
  team2: string;
};

export default function HomePage() {
  const [tournament, setTournament] =
    useState<Tournament | null>(null);

  const [players, setPlayers] =
    useState<Player[]>([]);

  const [currentRound, setCurrentRound] =
    useState<Round | null>(null);

  const [matches, setMatches] =
    useState<Match[]>([]);

  const [matchPlayers, setMatchPlayers] =
    useState<MatchPlayer[]>([]);

  const [standings, setStandings] =
    useState<Standing[]>([]);

  const [tournamentName, setTournamentName] =
    useState("");

  const [playerCount, setPlayerCount] =
    useState(24);

  const [preliminaryRounds, setPreliminaryRounds] =
    useState(6);

  const [courts, setCourts] =
    useState(3);

  const [playerInput, setPlayerInput] =
    useState("");

  const [inputMode, setInputMode] =
    useState<"manual" | "paste">("manual");

  const [manualPlayers, setManualPlayers] =
    useState<string[]>(
      Array.from({ length: 24 }, () => "")
    );

  const [scores, setScores] =
    useState<Record<string, ScoreState>>({});

  const [loading, setLoading] =
    useState(false);

  const [generatingNextRound, setGeneratingNextRound] =
    useState(false);

  const [status, setStatus] =
    useState("");

  /*
   * Restore the active tournament after browser refresh.
   */
  useEffect(() => {
    const activeTournamentId =
      localStorage.getItem("activeTournamentId");

    if (activeTournamentId) {
      loadTournamentData(activeTournamentId);
    }
  }, []);

  /*
   * Load tournament and current round.
   */
  async function loadTournamentData(
    tournamentId: string
  ) {
    try {
      setLoading(true);

      const { data: tournamentData, error: tournamentError } =
        await supabase
          .from("tournaments")
          .select("*")
          .eq("id", tournamentId)
          .single();

      if (tournamentError) {
        throw tournamentError;
      }

      setTournament(tournamentData);

      const { data: playerData, error: playerError } =
        await supabase
          .from("players")
          .select("*")
          .eq("tournament_id", tournamentId)
          .eq("active", true)
          .order("name");

      if (playerError) {
        throw playerError;
      }

      setPlayers(playerData || []);

      const { data: standingData, error: standingError } =
        await supabase
          .from("player_standings")
          .select("*")
          .eq("tournament_id", tournamentId);

      if (standingError) {
        throw standingError;
      }

      setStandings(standingData || []);

      const { data: roundsData, error: roundsError } =
        await supabase
          .from("rounds")
          .select("*")
          .eq("tournament_id", tournamentId)
          .order("round_number", {
            ascending: false,
          })
          .limit(1);

      if (roundsError) {
        throw roundsError;
      }

      if (!roundsData || roundsData.length === 0) {
        setCurrentRound(null);
        setMatches([]);
        setMatchPlayers([]);
        return;
      }

      const latestRound = roundsData[0];

      setCurrentRound(latestRound);

      const { data: matchData, error: matchError } =
        await supabase
          .from("matches")
          .select("*")
          .eq("round_id", latestRound.id)
          .order("match_number");

      if (matchError) {
        throw matchError;
      }

      setMatches(matchData || []);

      const matchIds =
        (matchData || []).map((match) => match.id);

      if (matchIds.length === 0) {
        setMatchPlayers([]);
      } else {
        const { data: matchPlayerData, error: matchPlayerError } =
          await supabase
            .from("match_players")
            .select("*")
            .in("match_id", matchIds);

        if (matchPlayerError) {
          throw matchPlayerError;
        }

        setMatchPlayers(matchPlayerData || []);

        const initialScores: Record<
          string,
          ScoreState
        > = {};

        (matchData || []).forEach((match) => {
          initialScores[match.id] = {
            team1:
              match.team1_score === null
                ? ""
                : String(match.team1_score),
            team2:
              match.team2_score === null
                ? ""
                : String(match.team2_score),
          };
        });

        setScores(initialScores);
      }
    } catch (error) {
      console.error(error);

      setStatus(
        error instanceof Error
          ? error.message
          : "Unable to load tournament."
      );
    } finally {
      setLoading(false);
    }
  }

  /*
   * Parse player names.
   */
  function getPlayerNames(): string[] {
    if (inputMode === "paste") {
      return playerInput
        .split(/\r?\n/)
        .map((name) => name.trim())
        .filter(Boolean);
    }

    return manualPlayers
      .map((name) => name.trim())
      .filter(Boolean);
  }

  /*
   * Create tournament.
   */
  async function createTournament() {
    try {
      setLoading(true);
      setStatus("");

      const names = getPlayerNames();

      if (!tournamentName.trim()) {
        setStatus("Please enter a tournament name.");
        return;
      }

      if (names.length !== playerCount) {
        setStatus(
          `Please enter exactly ${playerCount} player names. You entered ${names.length}.`
        );
        return;
      }

      const uniqueNames = new Set(
        names.map((name) => name.toLowerCase())
      );

      if (uniqueNames.size !== names.length) {
        setStatus(
          "Player names must be unique."
        );
        return;
      }

      if (playerCount % 4 !== 0) {
        setStatus(
          "Player count must be divisible by 4."
        );
        return;
      }

      const { data: tournamentData, error: tournamentError } =
        await supabase
          .from("tournaments")
          .insert({
            name: tournamentName.trim(),
            total_players: playerCount,
            preliminary_rounds: preliminaryRounds,
            courts,
            qualification_count: 16,
            status: "setup",
          })
          .select()
          .single();

      if (tournamentError) {
        throw tournamentError;
      }

      const playerRows = names.map(
        (name, index) => ({
          tournament_id: tournamentData.id,
          name,
          seed: index + 1,
          active: true,
        })
      );

      const { data: insertedPlayers, error: playersError } =
        await supabase
          .from("players")
          .insert(playerRows)
          .select();

      if (playersError) {
        throw playersError;
      }

      if (!insertedPlayers) {
        throw new Error(
          "Players were not created."
        );
      }

      const standingRows =
        insertedPlayers.map((player) => ({
          tournament_id: tournamentData.id,
          player_id: player.id,
          matches_played: 0,
          wins: 0,
          losses: 0,
          points_for: 0,
          points_against: 0,
          tournament_points: 0,
          rank: null,
        }));

      const { error: standingsError } =
        await supabase
          .from("player_standings")
          .insert(standingRows);

      if (standingsError) {
        throw standingsError;
      }

      const { error: scoringError } =
        await supabase
          .from("scoring_rules")
          .insert({
            tournament_id: tournamentData.id,
            points_per_game: 21,
            winner_score_multiplier: 1,
            loser_score_multiplier: 1,
          });

      if (scoringError) {
        throw scoringError;
      }

      localStorage.setItem(
        "activeTournamentId",
        tournamentData.id
      );

      setStatus(
        `Tournament created successfully! Tournament ID: ${tournamentData.id}`
      );

      await loadTournamentData(
        tournamentData.id
      );
    } catch (error) {
      console.error(error);

      setStatus(
        error instanceof Error
          ? error.message
          : "Unable to create tournament."
      );
    } finally {
      setLoading(false);
    }
  }

  /*
   * Calculate court assignment.
   *
   * Example:
   * 24 players / 6 matches / 3 courts
   *
   * Court 1 -> Match 1, Match 2
   * Court 2 -> Match 3, Match 4
   * Court 3 -> Match 5, Match 6
   */
  function getCourtNumber(
    matchIndex: number,
    matchCount: number,
    courtCount: number
  ) {
    const matchesPerCourt =
      Math.ceil(matchCount / courtCount);

    return Math.min(
      courtCount,
      Math.floor(
        matchIndex / matchesPerCourt
      ) + 1
    );
  }

  /*
   * Create matches and players for a round.
   */
  async function createRound(
    roundNumber: number,
    roundType: string,
    pairings: Pairing[]
  ) {
    if (!tournament) {
      throw new Error(
        "No active tournament."
      );
    }

    const { data: roundData, error: roundError } =
      await supabase
        .from("rounds")
        .insert({
          tournament_id: tournament.id,
          round_number: roundNumber,
          round_type: roundType,
          status: "generated",
        })
        .select()
        .single();

    if (roundError) {
      throw roundError;
    }

    const matchRows = pairings.map(
      (_, index) => ({
        round_id: roundData.id,
        court_number: getCourtNumber(
          index,
          pairings.length,
          tournament.courts
        ),
        match_number: index + 1,
        team1_score: null,
        team2_score: null,
        winner_team: null,
        status: "scheduled",
      })
    );

    const { data: insertedMatches, error: matchesError } =
      await supabase
        .from("matches")
        .insert(matchRows)
        .select();

    if (matchesError) {
      throw matchesError;
    }

    if (!insertedMatches) {
      throw new Error(
        "Matches were not created."
      );
    }

    const sortedMatches =
      [...insertedMatches].sort(
        (a, b) =>
          a.match_number -
          b.match_number
      );

    const matchPlayerRows: {
      match_id: string;
      player_id: string;
      team_number: number;
    }[] = [];

    pairings.forEach((pairing, index) => {
      const match = sortedMatches[index];

      pairing.team1.forEach((playerId) => {
        matchPlayerRows.push({
          match_id: match.id,
          player_id: playerId,
          team_number: 1,
        });
      });

      pairing.team2.forEach((playerId) => {
        matchPlayerRows.push({
          match_id: match.id,
          player_id: playerId,
          team_number: 2,
        });
      });
    });

    const { error: matchPlayerError } =
      await supabase
        .from("match_players")
        .insert(matchPlayerRows);

    if (matchPlayerError) {
      throw matchPlayerError;
    }

    await supabase
      .from("tournaments")
      .update({
        status: "in_progress",
      })
      .eq("id", tournament.id);

    await loadTournamentData(
      tournament.id
    );
  }

  /*
   * Generate Round 1.
   *
   * Round 1 is completely random.
   */
  async function generateRoundOne() {
    if (!tournament) {
      return;
    }

    if (currentRound) {
      setStatus(
        `Round ${currentRound.round_number} already exists.`
      );
      return;
    }

    try {
      setLoading(true);
      setStatus("");

      const shuffled = [...players];

      for (
        let i = shuffled.length - 1;
        i > 0;
        i--
      ) {
        const j = Math.floor(
          Math.random() * (i + 1)
        );

        [shuffled[i], shuffled[j]] =
          [shuffled[j], shuffled[i]];
      }

      const pairings: Pairing[] = [];

      for (
        let i = 0;
        i < shuffled.length;
        i += 4
      ) {
        pairings.push({
          team1: [
            shuffled[i].id,
            shuffled[i + 1].id,
          ],
          team2: [
            shuffled[i + 2].id,
            shuffled[i + 3].id,
          ],
        });
      }

      await createRound(
        1,
        "preliminary",
        pairings
      );

      setStatus(
        "Round 1 generated successfully."
      );
    } catch (error) {
      console.error(error);

      setStatus(
        error instanceof Error
          ? error.message
          : "Unable to generate Round 1."
      );
    } finally {
      setLoading(false);
    }
  }

  /*
   * Retrieve all previous match-player history.
   */
  async function getHistoricalMatchPlayers() {
    if (!tournament) {
      return [];
    }

    const { data: rounds, error: roundsError } =
      await supabase
        .from("rounds")
        .select("id")
        .eq("tournament_id", tournament.id);

    if (roundsError) {
      throw roundsError;
    }

    const roundIds =
      (rounds || []).map(
        (round) => round.id
      );

    if (roundIds.length === 0) {
      return [];
    }

    const { data: historicalMatches, error: matchesError } =
      await supabase
        .from("matches")
        .select("id")
        .in("round_id", roundIds);

    if (matchesError) {
      throw matchesError;
    }

    const matchIds =
      (historicalMatches || []).map(
        (match) => match.id
      );

    if (matchIds.length === 0) {
      return [];
    }

    const { data: historicalPlayers, error: playerError } =
      await supabase
        .from("match_players")
        .select(
          "match_id, player_id, team_number"
        )
        .in("match_id", matchIds);

    if (playerError) {
      throw playerError;
    }

    return historicalPlayers || [];
  }

  /*
   * Determine top 16.
   */
  function getTop16(): Player[] {
    const standingMap = new Map<
      string,
      Standing
    >();

    standings.forEach((standing) => {
      standingMap.set(
        standing.player_id,
        standing
      );
    });

    const sortedPlayers =
      [...players].sort((a, b) => {
        const aStanding =
          standingMap.get(a.id);

        const bStanding =
          standingMap.get(b.id);

        const aTournamentPoints =
          Number(
            aStanding?.tournament_points || 0
          );

        const bTournamentPoints =
          Number(
            bStanding?.tournament_points || 0
          );

        if (
          bTournamentPoints !==
          aTournamentPoints
        ) {
          return (
            bTournamentPoints -
            aTournamentPoints
          );
        }

        const aWins =
          Number(aStanding?.wins || 0);

        const bWins =
          Number(bStanding?.wins || 0);

        if (bWins !== aWins) {
          return bWins - aWins;
        }

        const aDifference =
          Number(
            aStanding?.points_for || 0
          ) -
          Number(
            aStanding?.points_against || 0
          );

        const bDifference =
          Number(
            bStanding?.points_for || 0
          ) -
          Number(
            bStanding?.points_against || 0
          );

        if (
          bDifference !==
          aDifference
        ) {
          return (
            bDifference -
            aDifference
          );
        }

        return (
          Number(
            bStanding?.points_for || 0
          ) -
          Number(
            aStanding?.points_for || 0
          )
        );
      });

    return sortedPlayers.slice(
      0,
      tournament?.qualification_count ||
        16
    );
  }

  /*
   * Generate next round:
   *
   * Preliminary -> Intelligent
   * Final preliminary -> QF
   * QF -> SF
   * SF -> Final
   */
  async function generateNextRound() {
    if (!tournament || !currentRound) {
      return;
    }

    if (
      currentRound.status !==
      "completed"
    ) {
      setStatus(
        "Complete all matches in the current round before generating the next round."
      );
      return;
    }

    try {
      setGeneratingNextRound(true);
      setStatus("");

      /*
       * PRELIMINARY -> PRELIMINARY
       */
      if (
        currentRound.round_type ===
          "preliminary" &&
        currentRound.round_number <
          tournament.preliminary_rounds
      ) {
        const historicalPlayers =
          await getHistoricalMatchPlayers();

        const enginePlayers =
          players.map((player) => ({
            id: player.id,
            name: player.name,
          }));

        const engineStandings =
          standings.map((standing) => ({
            player_id:
              standing.player_id,
            tournament_points:
              standing.tournament_points,
            wins: standing.wins,
            losses: standing.losses,
            points_for:
              standing.points_for,
            points_against:
              standing.points_against,
          }));

        const pairings =
          generateIntelligentPairings(
            enginePlayers,
            engineStandings,
            historicalPlayers,
            5000
          );

        await createRound(
          currentRound.round_number + 1,
          "preliminary",
          pairings
        );

        setStatus(
          `Round ${
            currentRound.round_number + 1
          } generated using intelligent pairing.`
        );

        return;
      }

      /*
       * FINAL PRELIMINARY -> QUARTERFINALS
       */
      if (
        currentRound.round_type ===
          "preliminary" &&
        currentRound.round_number ===
          tournament.preliminary_rounds
      ) {
        const top16 = getTop16();

        if (top16.length < 16) {
          throw new Error(
            "At least 16 qualified players are required for the Quarterfinals."
          );
        }

        const pairings =
          generateRandomPairings(
            top16.map((player) => ({
              id: player.id,
              name: player.name,
            }))
          );

        await createRound(
          currentRound.round_number + 1,
          "quarterfinal",
          pairings
        );

        setStatus(
          "Quarterfinals generated from the Top 16."
        );

        return;
      }

      /*
       * QUARTERFINALS -> SEMIFINALS
       */
      if (
        currentRound.round_type ===
        "quarterfinal"
      ) {
        const winners: string[] = [];

        for (const match of matches) {
          if (!match.winner_team) {
            continue;
          }

          const teamPlayers =
            matchPlayers.filter(
              (player) =>
                player.match_id ===
                  match.id &&
                player.team_number ===
                  match.winner_team
            );

          teamPlayers.forEach(
            (player) =>
              winners.push(
                player.player_id
              )
          );
        }

        if (winners.length !== 8) {
          throw new Error(
            "All four Quarterfinal matches must be completed before generating the Semifinals."
          );
        }

        const winnerPlayers =
          winners
            .map((id) =>
              players.find(
                (player) =>
                  player.id === id
              )
            )
            .filter(
              (
                player
              ): player is Player =>
                Boolean(player)
            );

        const pairings =
          generateRandomPairings(
            winnerPlayers.map((player) => ({
              id: player.id,
              name: player.name,
            }))
          );

        await createRound(
          currentRound.round_number + 1,
          "semifinal",
          pairings
        );

        setStatus(
          "Semifinals generated from the Quarterfinal winners."
        );

        return;
      }

      /*
       * SEMIFINALS -> FINAL
       */
      if (
        currentRound.round_type ===
        "semifinal"
      ) {
        const winners: string[] = [];

        for (const match of matches) {
          if (!match.winner_team) {
            continue;
          }

          const teamPlayers =
            matchPlayers.filter(
              (player) =>
                player.match_id ===
                  match.id &&
                player.team_number ===
                  match.winner_team
            );

          teamPlayers.forEach(
            (player) =>
              winners.push(
                player.player_id
              )
          );
        }

        if (winners.length !== 4) {
          throw new Error(
            "Both Semifinal matches must be completed before generating the Final."
          );
        }

        const winnerPlayers =
          winners
            .map((id) =>
              players.find(
                (player) =>
                  player.id === id
              )
            )
            .filter(
              (
                player
              ): player is Player =>
                Boolean(player)
            );

        const pairings =
          generateRandomPairings(
            winnerPlayers.map((player) => ({
              id: player.id,
              name: player.name,
            }))
          );

        await createRound(
          currentRound.round_number + 1,
          "final",
          pairings
        );

        setStatus(
          "Final generated."
        );

        return;
      }

      if (
        currentRound.round_type ===
        "final"
      ) {
        setStatus(
          "The tournament is already complete."
        );
      }
    } catch (error) {
      console.error(error);

      setStatus(
        error instanceof Error
          ? error.message
          : "Unable to generate the next round."
      );
    } finally {
      setGeneratingNextRound(false);
    }
  }

  /*
   * Update score input.
   */
  function updateScore(
    matchId: string,
    team: "team1" | "team2",
    value: string
  ) {
    setScores((previous) => ({
      ...previous,
      [matchId]: {
        ...(previous[matchId] || {
          team1: "",
          team2: "",
        }),
        [team]: value,
      },
    }));
  }

  /*
   * Save a match result.
   *
   * Scoring:
   *
   * 21 - 12
   *
   * Winner gets:
   * 21 / 2 = 10.5
   *
   * Loser gets:
   * 12 / 2 = 6
   */
  async function saveMatchResult(
    match: Match
  ) {
    try {
      const score =
        scores[match.id];

      if (!score) {
        setStatus(
          "Please enter both scores."
        );
        return;
      }

      const team1Score =
        Number(score.team1);

      const team2Score =
        Number(score.team2);

      if (
        !Number.isFinite(
          team1Score
        ) ||
        !Number.isFinite(
          team2Score
        )
      ) {
        setStatus(
          "Scores must be valid numbers."
        );
        return;
      }

      if (
        team1Score < 0 ||
        team2Score < 0
      ) {
        setStatus(
          "Scores cannot be negative."
        );
        return;
      }

      if (
        team1Score === team2Score
      ) {
        setStatus(
          "Badminton matches cannot end in a tie."
        );
        return;
      }

      if (match.status === "completed") {
        setStatus(
          "This match has already been saved."
        );
        return;
      }

      const winnerTeam =
        team1Score > team2Score
          ? 1
          : 2;

      const winnerScore =
        winnerTeam === 1
          ? team1Score
          : team2Score;

      const loserScore =
        winnerTeam === 1
          ? team2Score
          : team1Score;

      const winnerPoints =
        winnerScore / 2;

      const loserPoints =
        loserScore / 2;

      const team1Players =
        matchPlayers.filter(
          (player) =>
            player.match_id ===
              match.id &&
            player.team_number === 1
        );

      const team2Players =
        matchPlayers.filter(
          (player) =>
            player.match_id ===
              match.id &&
            player.team_number === 2
        );

      if (
        team1Players.length !== 2 ||
        team2Players.length !== 2
      ) {
        setStatus(
          "Each match must have exactly 2 players per team."
        );
        return;
      }

      /*
       * Update match only if it is still scheduled.
       * This prevents double-saving.
       */
      const { data: updatedMatch, error: matchError } =
        await supabase
          .from("matches")
          .update({
            team1_score:
              team1Score,
            team2_score:
              team2Score,
            winner_team:
              winnerTeam,
            status: "completed",
          })
          .eq("id", match.id)
          .eq("status", "scheduled")
          .select("id")
          .maybeSingle();

      if (matchError) {
        throw matchError;
      }

      if (!updatedMatch) {
        setStatus(
          "This match has already been saved."
        );
        return;
      }

      /*
       * Update Team 1
       */
      for (const player of team1Players) {
        const isWinner =
          winnerTeam === 1;

        const pointsFor =
          isWinner
            ? winnerPoints
            : loserPoints;

        const pointsAgainst =
          isWinner
            ? loserPoints
            : winnerPoints;

        const { data: standing, error: standingError } =
          await supabase
            .from("player_standings")
            .select("*")
            .eq(
              "tournament_id",
              tournament!.id
            )
            .eq(
              "player_id",
              player.player_id
            )
            .single();

        if (standingError) {
          throw standingError;
        }

        const { error: updateError } =
          await supabase
            .from("player_standings")
            .update({
              matches_played:
                Number(
                  standing.matches_played
                ) + 1,

              wins:
                Number(
                  standing.wins
                ) +
                (isWinner ? 1 : 0),

              losses:
                Number(
                  standing.losses
                ) +
                (isWinner ? 0 : 1),

              points_for:
                Number(
                  standing.points_for
                ) + pointsFor,

              points_against:
                Number(
                  standing.points_against
                ) + pointsAgainst,

              tournament_points:
                Number(
                  standing.tournament_points
                ) + pointsFor,
            })
            .eq(
              "tournament_id",
              tournament!.id
            )
            .eq(
              "player_id",
              player.player_id
            );

        if (updateError) {
          throw updateError;
        }
      }

      /*
       * Update Team 2
       */
      for (const player of team2Players) {
        const isWinner =
          winnerTeam === 2;

        const pointsFor =
          isWinner
            ? winnerPoints
            : loserPoints;

        const pointsAgainst =
          isWinner
            ? loserPoints
            : winnerPoints;

        const { data: standing, error: standingError } =
          await supabase
            .from("player_standings")
            .select("*")
            .eq(
              "tournament_id",
              tournament!.id
            )
            .eq(
              "player_id",
              player.player_id
            )
            .single();

        if (standingError) {
          throw standingError;
        }

        const { error: updateError } =
          await supabase
            .from("player_standings")
            .update({
              matches_played:
                Number(
                  standing.matches_played
                ) + 1,

              wins:
                Number(
                  standing.wins
                ) +
                (isWinner ? 1 : 0),

              losses:
                Number(
                  standing.losses
                ) +
                (isWinner ? 0 : 1),

              points_for:
                Number(
                  standing.points_for
                ) + pointsFor,

              points_against:
                Number(
                  standing.points_against
                ) + pointsAgainst,

              tournament_points:
                Number(
                  standing.tournament_points
                ) + pointsFor,
            })
            .eq(
              "tournament_id",
              tournament!.id
            )
            .eq(
              "player_id",
              player.player_id
            );

        if (updateError) {
          throw updateError;
        }
      }

      /*
       * Check whether all matches in this round
       * are completed.
       */
      const { data: roundMatches, error: roundMatchesError } =
        await supabase
          .from("matches")
          .select("id, status")
          .eq(
            "round_id",
            currentRound!.id
          );

      if (roundMatchesError) {
        throw roundMatchesError;
      }

      const allCompleted =
        (roundMatches || []).length > 0 &&
        (roundMatches || []).every(
          (m) =>
            m.status ===
            "completed"
        );

      if (allCompleted) {
        const { error: roundError } =
          await supabase
            .from("rounds")
            .update({
              status: "completed",
            })
            .eq(
              "id",
              currentRound!.id
            );

        if (roundError) {
          throw roundError;
        }

        if (
          currentRound!.round_type ===
          "final"
        ) {
          await supabase
            .from("tournaments")
            .update({
              status: "completed",
            })
            .eq(
              "id",
              tournament!.id
            );

          setStatus(
            "🏆 Final completed! Tournament is complete."
          );
        } else {
          setStatus(
            `✓ ${
              getRoundDisplayName(
                currentRound
              )
            } completed. Ready for the next round.`
          );
        }
      } else {
        setStatus(
          `Match ${match.match_number} saved successfully.`
        );
      }

      await loadTournamentData(
        tournament!.id
      );
    } catch (error) {
      console.error(error);

      setStatus(
        error instanceof Error
          ? error.message
          : "Unable to save match result."
      );
    }
  }

  function getRoundDisplayName(
    round: Round
  ) {
    switch (round.round_type) {
      case "preliminary":
        return `Round ${round.round_number}`;

      case "quarterfinal":
        return "Quarterfinals";

      case "semifinal":
        return "Semifinals";

      case "final":
        return "Final";

      default:
        return `Round ${round.round_number}`;
    }
  }

  function getTeamPlayers(
    matchId: string,
    teamNumber: number
  ) {
    return matchPlayers
      .filter(
        (player) =>
          player.match_id ===
            matchId &&
          player.team_number ===
            teamNumber
      )
      .map((player) =>
        players.find(
          (p) =>
            p.id ===
            player.player_id
        )
      )
      .filter(
        (
          player
        ): player is Player =>
          Boolean(player)
      );
  }

  const matchesByCourt =
    useMemo(() => {
      const grouped =
        new Map<
          number,
          Match[]
        >();

      matches.forEach((match) => {
        const court =
          match.court_number || 1;

        if (!grouped.has(court)) {
          grouped.set(
            court,
            []
          );
        }

        grouped
          .get(court)!
          .push(match);
      });

      return grouped;
    }, [matches]);

  const completedMatches =
    matches.filter(
      (match) =>
        match.status ===
        "completed"
    ).length;

  const progress =
    matches.length === 0
      ? 0
      : Math.round(
          (completedMatches /
            matches.length) *
            100
        );

  const top16 =
    currentRound &&
    currentRound.round_type ===
      "preliminary" &&
    currentRound.round_number ===
      tournament?.preliminary_rounds
      ? getTop16()
      : [];

  function isCurrentRoundComplete() {
    return (
      currentRound?.status ===
      "completed"
    );
  }

  function getNextRoundButtonText() {
    if (!currentRound) {
      return "";
    }

    if (
      currentRound.round_type ===
        "preliminary" &&
      currentRound.round_number <
        (tournament?.preliminary_rounds ||
          0)
    ) {
      return `Generate Round ${
        currentRound.round_number + 1
      } — Intelligent Pairing`;
    }

    if (
      currentRound.round_type ===
        "preliminary" &&
      currentRound.round_number ===
        tournament?.preliminary_rounds
    ) {
      return "Generate Quarterfinals — Top 16";
    }

    if (
      currentRound.round_type ===
      "quarterfinal"
    ) {
      return "Generate Semifinals";
    }

    if (
      currentRound.round_type ===
      "semifinal"
    ) {
      return "Generate Final";
    }

    return "";
  }

  function startNewTournament() {
    localStorage.removeItem(
      "activeTournamentId"
    );

    window.location.href = "/";
  }

  /*
   * SETUP SCREEN
   */
  if (!tournament) {
    return (
      <main className="min-h-screen bg-slate-950 text-white">
        <div className="mx-auto max-w-5xl px-6 py-10">
          <div className="mb-10">
            <h1 className="text-4xl font-bold">
              🏸 Badminton Tournament Manager
            </h1>

            <p className="mt-3 text-slate-400">
              Create and manage your complete
              doubles tournament.
            </p>
          </div>

          <div className="rounded-2xl border border-slate-800 bg-slate-900 p-6">
            <h2 className="mb-6 text-2xl font-bold">
              Tournament Setup
            </h2>

            <div className="grid gap-6 md:grid-cols-3">
              <div>
                <label className="mb-2 block text-sm font-semibold text-slate-300">
                  Tournament Name
                </label>

                <input
                  value={tournamentName}
                  onChange={(e) =>
                    setTournamentName(
                      e.target.value
                    )
                  }
                  placeholder="Weekend Badminton Tournament"
                  className="w-full rounded-lg border border-slate-700 bg-slate-950 px-4 py-3 outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="mb-2 block text-sm font-semibold text-slate-300">
                  Players
                </label>

                <select
                  value={playerCount}
                  onChange={(e) =>
                    setPlayerCount(
                      Number(
                        e.target.value
                      )
                    )
                  }
                  className="w-full rounded-lg border border-slate-700 bg-slate-950 px-4 py-3"
                >
                  <option value={16}>
                    16 Players
                  </option>

                  <option value={24}>
                    24 Players
                  </option>

                  <option value={32}>
                    32 Players
                  </option>
                </select>
              </div>

              <div>
                <label className="mb-2 block text-sm font-semibold text-slate-300">
                  Preliminary Rounds
                </label>

                <select
                  value={
                    preliminaryRounds
                  }
                  onChange={(e) =>
                    setPreliminaryRounds(
                      Number(
                        e.target.value
                      )
                    )
                  }
                  className="w-full rounded-lg border border-slate-700 bg-slate-950 px-4 py-3"
                >
                  {[4, 5, 6, 7, 8].map(
                    (round) => (
                      <option
                        key={round}
                        value={round}
                      >
                        {round} Rounds
                      </option>
                    )
                  )}
                </select>
              </div>

              <div>
                <label className="mb-2 block text-sm font-semibold text-slate-300">
                  Courts
                </label>

                <select
                  value={courts}
                  onChange={(e) =>
                    setCourts(
                      Number(
                        e.target.value
                      )
                    )
                  }
                  className="w-full rounded-lg border border-slate-700 bg-slate-950 px-4 py-3"
                >
                  <option value={2}>
                    2 Courts
                  </option>

                  <option value={3}>
                    3 Courts
                  </option>

                  <option value={4}>
                    4 Courts
                  </option>
                </select>
              </div>
            </div>

            <div className="mt-8 flex gap-3">
              <button
                onClick={() =>
                  setInputMode(
                    "manual"
                  )
                }
                className={`rounded-lg px-4 py-2 font-semibold ${
                  inputMode === "manual"
                    ? "bg-emerald-600"
                    : "bg-slate-800"
                }`}
              >
                Enter Players
              </button>

              <button
                onClick={() =>
                  setInputMode(
                    "paste"
                  )
                }
                className={`rounded-lg px-4 py-2 font-semibold ${
                  inputMode === "paste"
                    ? "bg-emerald-600"
                    : "bg-slate-800"
                }`}
              >
                Paste List
              </button>
            </div>

            {inputMode === "manual" ? (
              <div className="mt-6 grid gap-3 md:grid-cols-2">
                {Array.from({
                  length: playerCount,
                }).map((_, index) => (
                  <input
                    key={index}
                    value={
                      manualPlayers[
                        index
                      ] || ""
                    }
                    onChange={(e) => {
                      const updated =
                        [
                          ...manualPlayers,
                        ];

                      updated[
                        index
                      ] =
                        e.target.value;

                      setManualPlayers(
                        updated
                      );
                    }}
                    placeholder={`Player ${
                      index + 1
                    }`}
                    className="rounded-lg border border-slate-700 bg-slate-950 px-4 py-3"
                  />
                ))}
              </div>
            ) : (
              <div className="mt-6">
                <textarea
                  value={
                    playerInput
                  }
                  onChange={(e) =>
                    setPlayerInput(
                      e.target.value
                    )
                  }
                  placeholder={`Paste one player per line\nPlayer 1\nPlayer 2\nPlayer 3`}
                  rows={12}
                  className="w-full rounded-lg border border-slate-700 bg-slate-950 px-4 py-3"
                />

                <p className="mt-2 text-sm text-slate-500">
                  Enter exactly{" "}
                  {playerCount}{" "}
                  players.
                </p>
              </div>
            )}

            <div className="mt-8 flex flex-wrap gap-3">
              <button
                onClick={createTournament}
                disabled={loading}
                className="rounded-lg bg-emerald-600 px-6 py-3 font-bold hover:bg-emerald-500 disabled:opacity-50"
              >
                {loading
                  ? "Creating..."
                  : "Create Tournament"}
              </button>

              <button
                onClick={() => {
                  window.location.href =
                    "/leaderboard";
                }}
                className="rounded-lg border border-emerald-700 px-6 py-3 font-semibold text-emerald-400 hover:bg-emerald-950"
              >
                📊 Leaderboard
              </button>
            </div>

            {status && (
              <div className="mt-6 rounded-lg border border-slate-700 bg-slate-950 p-4 text-sm">
                {status}
              </div>
            )}
          </div>
        </div>
      </main>
    );
  }

  /*
   * DASHBOARD
   */
  return (
    <main className="min-h-screen bg-slate-950 text-white">
      <div className="mx-auto max-w-7xl px-6 py-8">
        <div className="mb-8 flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <h1 className="text-3xl font-bold">
              🏸 {tournament.name}
            </h1>

            <p className="mt-2 text-slate-400">
              {tournament.total_players} players ·{" "}
              {tournament.courts} courts ·{" "}
              {tournament.preliminary_rounds}{" "}
              preliminary rounds
            </p>
          </div>

          <div className="flex flex-wrap gap-3">
            <button
              onClick={() =>
                loadTournamentData(
                  tournament.id
                )
              }
              className="rounded-lg border border-slate-700 px-4 py-2 text-sm font-semibold hover:bg-slate-800"
            >
              🔄 Refresh
            </button>

            <button
              onClick={() => {
                window.location.href =
                  "/leaderboard";
              }}
              className="rounded-lg border border-emerald-700 px-4 py-2 text-sm font-semibold text-emerald-400 hover:bg-emerald-950"
            >
              📊 Leaderboard
            </button>

            <button
              onClick={startNewTournament}
              className="rounded-lg border border-slate-700 px-4 py-2 text-sm font-semibold hover:bg-slate-800"
            >
              ➕ New Tournament
            </button>
          </div>
        </div>

        {currentRound && (
          <div className="mb-6 grid gap-4 md:grid-cols-4">
            <div className="rounded-xl border border-slate-800 bg-slate-900 p-5">
              <p className="text-sm text-slate-400">
                Current Stage
              </p>

              <p className="mt-1 text-xl font-bold">
                {getRoundDisplayName(
                  currentRound
                )}
              </p>
            </div>

            <div className="rounded-xl border border-slate-800 bg-slate-900 p-5">
              <p className="text-sm text-slate-400">
                Matches
              </p>

              <p className="mt-1 text-xl font-bold">
                {completedMatches} /{" "}
                {matches.length}
              </p>
            </div>

            <div className="rounded-xl border border-slate-800 bg-slate-900 p-5">
              <p className="text-sm text-slate-400">
                Progress
              </p>

              <p className="mt-1 text-xl font-bold">
                {progress}%
              </p>
            </div>

            <div className="rounded-xl border border-slate-800 bg-slate-900 p-5">
              <p className="text-sm text-slate-400">
                Status
              </p>

              <p
                className={`mt-1 text-xl font-bold ${
                  currentRound.status ===
                  "completed"
                    ? "text-emerald-400"
                    : "text-yellow-400"
                }`}
              >
                {currentRound.status ===
                "completed"
                  ? "Completed"
                  : "In Progress"}
              </p>
            </div>
          </div>
        )}

        {status && (
          <div className="mb-6 rounded-xl border border-slate-700 bg-slate-900 p-4">
            {status}
          </div>
        )}

        {!currentRound ? (
          <div className="rounded-2xl border border-slate-800 bg-slate-900 p-8">
            <h2 className="text-2xl font-bold">
              Ready to Start
            </h2>

            <p className="mt-2 text-slate-400">
              Round 1 will randomly pair all
              players.
            </p>

            <button
              onClick={generateRoundOne}
              disabled={loading}
              className="mt-6 rounded-lg bg-emerald-600 px-6 py-3 font-bold hover:bg-emerald-500 disabled:opacity-50"
            >
              {loading
                ? "Generating..."
                : "🎲 Generate Round 1"}
            </button>
          </div>
        ) : (
          <>
            <div className="mb-8 rounded-xl border border-slate-800 bg-slate-900 p-5">
              <div className="mb-3 flex items-center justify-between">
                <div>
                  <h2 className="font-bold">
                    {getRoundDisplayName(
                      currentRound
                    )}
                  </h2>

                  <p className="text-sm text-slate-400">
                    Enter the final score for
                    each match.
                  </p>
                </div>

                <span className="font-bold text-emerald-400">
                  {progress}%
                </span>
              </div>

              <div className="h-3 overflow-hidden rounded-full bg-slate-800">
                <div
                  className="h-full rounded-full bg-emerald-500 transition-all"
                  style={{
                    width: `${progress}%`,
                  }}
                />
              </div>
            </div>

            {Array.from(
              {
                length:
                  tournament.courts,
              },
              (_, index) =>
                index + 1
            ).map((courtNumber) => {
              const courtMatches =
                matchesByCourt.get(
                  courtNumber
                ) || [];

              if (
                courtMatches.length ===
                0
              ) {
                return null;
              }

              return (
                <section
                  key={courtNumber}
                  className="mb-8"
                >
                  <h2 className="mb-4 text-2xl font-bold">
                    Court{" "}
                    {courtNumber}
                  </h2>

                  <div className="grid gap-5 lg:grid-cols-2">
                    {courtMatches.map(
                      (match) => {
                        const team1 =
                          getTeamPlayers(
                            match.id,
                            1
                          );

                        const team2 =
                          getTeamPlayers(
                            match.id,
                            2
                          );

                        const score =
                          scores[
                            match.id
                          ] || {
                            team1: "",
                            team2: "",
                          };

                        const completed =
                          match.status ===
                          "completed";

                        return (
                          <div
                            key={
                              match.id
                            }
                            className={`rounded-xl border p-5 ${
                              completed
                                ? "border-emerald-900 bg-emerald-950/20"
                                : "border-slate-800 bg-slate-900"
                            }`}
                          >
                            <div className="mb-5 flex items-center justify-between">
                              <h3 className="text-lg font-bold">
                                Match{" "}
                                {
                                  match.match_number
                                }
                              </h3>

                              <span
                                className={`rounded-full px-3 py-1 text-xs font-bold ${
                                  completed
                                    ? "bg-emerald-900 text-emerald-300"
                                    : "bg-yellow-900 text-yellow-300"
                                }`}
                              >
                                {completed
                                  ? "COMPLETED"
                                  : "SCHEDULED"}
                              </span>
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                              <div className="rounded-lg border border-slate-700 bg-slate-950 p-4">
                                <p className="mb-3 font-bold text-emerald-400">
                                  Team 1
                                </p>

                                {team1.map(
                                  (
                                    player
                                  ) => (
                                    <p
                                      key={
                                        player.id
                                      }
                                      className="text-sm"
                                    >
                                      {
                                        player.name
                                      }
                                    </p>
                                  )
                                )}

                                <input
                                  type="number"
                                  min="0"
                                  value={
                                    score.team1
                                  }
                                  disabled={
                                    completed
                                  }
                                  onChange={(
                                    e
                                  ) =>
                                    updateScore(
                                      match.id,
                                      "team1",
                                      e.target
                                        .value
                                    )
                                  }
                                  className="mt-4 w-full rounded-lg border border-slate-700 bg-slate-900 px-3 py-2 text-center text-xl font-bold disabled:opacity-50"
                                  placeholder="Score"
                                />
                              </div>

                              <div className="rounded-lg border border-slate-700 bg-slate-950 p-4">
                                <p className="mb-3 font-bold text-blue-400">
                                  Team 2
                                </p>

                                {team2.map(
                                  (
                                    player
                                  ) => (
                                    <p
                                      key={
                                        player.id
                                      }
                                      className="text-sm"
                                    >
                                      {
                                        player.name
                                      }
                                    </p>
                                  )
                                )}

                                <input
                                  type="number"
                                  min="0"
                                  value={
                                    score.team2
                                  }
                                  disabled={
                                    completed
                                  }
                                  onChange={(
                                    e
                                  ) =>
                                    updateScore(
                                      match.id,
                                      "team2",
                                      e.target
                                        .value
                                    )
                                  }
                                  className="mt-4 w-full rounded-lg border border-slate-700 bg-slate-900 px-3 py-2 text-center text-xl font-bold disabled:opacity-50"
                                  placeholder="Score"
                                />
                              </div>
                            </div>

                            {!completed && (
                              <button
                                onClick={() =>
                                  saveMatchResult(
                                    match
                                  )
                                }
                                className="mt-5 w-full rounded-lg bg-emerald-600 px-4 py-3 font-bold hover:bg-emerald-500"
                              >
                                💾 Save Result
                              </button>
                            )}
                          </div>
                        );
                      }
                    )}
                  </div>
                </section>
              );
            })}

            {isCurrentRoundComplete() &&
              currentRound.round_type !==
                "final" && (
                <div className="mt-8 rounded-2xl border border-emerald-800 bg-emerald-950/30 p-6">
                  <div className="flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
                    <div>
                      <h2 className="text-2xl font-bold text-emerald-400">
                        ✓{" "}
                        {getRoundDisplayName(
                          currentRound
                        )}{" "}
                        Complete
                      </h2>

                      <p className="mt-2 text-slate-300">
                        All matches have been
                        completed. You can now
                        generate the next stage.
                      </p>
                    </div>

                    <button
                      onClick={
                        generateNextRound
                      }
                      disabled={
                        generatingNextRound
                      }
                      className="rounded-lg bg-emerald-600 px-6 py-3 font-bold hover:bg-emerald-500 disabled:opacity-50"
                    >
                      {generatingNextRound
                        ? "Generating..."
                        : getNextRoundButtonText()}
                    </button>
                  </div>
                </div>
              )}

            {isCurrentRoundComplete() &&
              currentRound.round_type ===
                "final" && (
                <div className="mt-8 rounded-2xl border border-yellow-700 bg-yellow-950/30 p-8 text-center">
                  <div className="text-5xl">
                    🏆
                  </div>

                  <h2 className="mt-4 text-3xl font-bold text-yellow-400">
                    Tournament Complete!
                  </h2>

                  <p className="mt-2 text-slate-300">
                    The Final has been
                    completed.
                  </p>

                  <button
                    onClick={() => {
                      window.location.href =
                        "/leaderboard";
                    }}
                    className="mt-6 rounded-lg bg-yellow-600 px-6 py-3 font-bold text-black hover:bg-yellow-500"
                  >
                    📊 View Final Leaderboard
                  </button>
                </div>
              )}

            {top16.length === 16 && (
              <div className="mt-8 rounded-2xl border border-purple-800 bg-purple-950/20 p-6">
                <h2 className="text-2xl font-bold text-purple-300">
                  🏆 Top 16 Qualified
                </h2>

                <p className="mt-2 text-sm text-slate-400">
                  These players will enter the
                  Quarterfinals.
                </p>

                <div className="mt-5 grid gap-2 md:grid-cols-2 lg:grid-cols-4">
                  {top16.map(
                    (
                      player,
                      index
                    ) => (
                      <div
                        key={
                          player.id
                        }
                        className="rounded-lg border border-slate-800 bg-slate-900 p-3"
                      >
                        <span className="mr-2 font-bold text-purple-400">
                          #{index + 1}
                        </span>

                        {
                          player.name
                        }
                      </div>
                    )
                  )}
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </main>
  );
}